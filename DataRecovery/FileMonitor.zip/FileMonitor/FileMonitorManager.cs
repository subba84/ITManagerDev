﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataRecovery.Common;

namespace DataRecovery.FileMonitor
{
    public class FileMonitorManager
    {
        public void SearcFiles()
        {
            var drives = DriveInfo.GetDrives().Where(drive => drive.IsReady && drive.DriveType != DriveType.CDRom && drive.DriveType != DriveType.Network && drive.DriveType != DriveType.Removable).ToList();
            var extensions = new List<string> { ".txt", ".xml" };
            List<FileModel> objlstFileModel = new List<FileModel>();

            foreach (var item in drives)
            {
                try
                {
                    var directories = Directory.GetDirectories("D:\\Test");

                    List<DirectoryInfo> diinfo = new List<DirectoryInfo>();

                    var supportedExtensions = System.Configuration.ConfigurationManager.AppSettings["FileExtensions"].ToString();

                    foreach (var dir in directories)
                    {
                        DirectoryInfo di = new DirectoryInfo(dir);
                        if (!di.Attributes.ToString().Contains("Hidden"))
                        {

                            List<FileModel> files = Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories)
                                            .Where(f => extensions.IndexOf(Path.GetExtension(f)) >= 0 && supportedExtensions.Contains(Path.GetExtension(f).ToLower())).ToArray().Select(k => new FileModel { FileName = k, Filestatus = "Pending", FileAction = "Scan", FileActionDate = DateTime.Now }).ToList();


                            foreach (var fileobject in files)
                            {
                                Logger.LogXml(fileobject);
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex.Message + ex.StackTrace);
                }

            }
        }

        public void Search()
        {
            using (OleDbConnection conn = new OleDbConnection("Provider=Search.CollatorDSO;Extended Properties='Application=Windows';"))
            {
                conn.Open();
                OleDbCommand cmd = new OleDbCommand(".txt", conn);

                using (OleDbDataReader reader = cmd.ExecuteReader())
                {

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        FileModel objFileModel = new FileModel();

                        objFileModel.FileName = reader.GetName(i);

                        Logger.LogXml(objFileModel);

                    }

                    while (reader.Read())
                    {
                        List<object> row = new List<object>();

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row.Add(reader[i]);
                        }

                    }
                }
            }
        }
    }
}
